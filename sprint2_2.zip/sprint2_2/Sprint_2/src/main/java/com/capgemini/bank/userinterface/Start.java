package com.capgemini.bank.userinterface;

import java.sql.ResultSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.service.AccountServiceImpl;



public class Start {
	static AccountServiceImpl services=new AccountServiceImpl();
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		int choice;
		boolean result;
		while(true)
		{
			 System.out.println("01. Create an account");
				System.out.println("02. Add balance to account");
				System.out.println("03. Show details");
				System.out.println("04. Transfer money to other account");
				System.out.println("05. Show all accounts available");
				System.out.println("06. Exit from service");
				System.out.print("Enter your choice : ");
			choice = scan.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Account Creation");
				try
				{
					Account user=new Account();
					System.out.println("Enter your name:");
					user.setName(scan.next());
					System.out.println("Enter your phone number:");
					user.setPhoneNumber(scan.nextLong());
					System.out.println("Enter your email:");
					user.setEmailid(scan.next());
					user.setBalance(0);
					String AccountNumber=services.createAccount(user);
					System.out.println("Account Number is : "+AccountNumber);
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 2:
				System.out.println("Adding Money");
				try {
					System.out.println("Enter the account number to add money:");
					String AccountNumber=scan.next();
					System.out.println("Enter the amount to add in to the account "+AccountNumber);
					int Amount=scan.nextInt();
					result=services.addMoney(AccountNumber, Amount);
					if(result) {
						System.out.println("Money successfully added");
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 3:
				System.out.println("View Account Details");
				try
				{
					System.out.println("Enter the Account Number of which you want the details");
					String AccountNumber=scan.next();
					Account user=services.viewAccount(AccountNumber);
					System.out.println("Name="+user.getName()+"\nPhone="+user.getPhoneNumber()+"\nEmail="+user.getEmailid()+"\nBalance="+user.getBalance());
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 4:
				System.out.println("Money Transfer");
				try
				{
					System.out.println("Enter the sender Account Number");
					String SenderAccountNumber=scan.next();
					System.out.println("Enter the Reciever Account Number");
					String RecieverAccountNumber=scan.next();
					System.out.println("Enter the amount to be transferred");
					int TransferAmount=scan.nextInt();
					result=services.transfer(SenderAccountNumber, RecieverAccountNumber, TransferAmount);
					if(result) {
						System.out.println("Money transfered successfully");
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 5:
				try
				{
					ResultSet res=services.getAllAccounts();
					while(res.next())
					{
						System.out.println("Account Number: "+res.getString(1)+"\t\tName: "+res.getString(2));
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 6:
				System.exit(0);
			default:
				break;
			}
		}
	}

}
