create database db1;
use db1;
create table accounts(accnumber varchar(10) primary key,name varchar(20),phnumber bigint(10),email varchar(20),balance int(5));
select * from accounts;